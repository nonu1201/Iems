KIWI EARS CADENZA 2 - WAVELET EQ PRESETS
============================================

HOW TO USE
- Pick the folder for what you are listening to in "By genre".
  File "1" is my first choice for that genre, "6" my last.
- In Wavelet, open AutoEq and use its import option to load the .txt.
- The preamp is already built into every file (loudest band is -0.5 dB
  or lower), so it cannot clip. Do not add extra gain.
- Turn off Dolby Atmos / Adapt Sound / other EQs while comparing.
- Players that use exclusive or "bit-perfect" USB output bypass Wavelet;
  use normal Android output.
- "All presets" has the same six files once each, named by what they are for.
- "PEQ (other apps)" has the same EQs as parametric filters for apps that
  import EqualizerAPO-style PEQ. "Plots" shows raw vs EQd vs target.

THE SIX PRESETS
- HBB Bad Guy 2022: punchy mid-bass, relaxed upper mids (-1 to -2 dB at 1-5 kHz), a little sparkle. Fun but never shouty.
- IEF Preference 2025: stock bass, vocals a bit forward (+1.6 dB at 3 kHz), less sibilance (-2 dB at 5-6 kHz). The smoothest.
- Delta JM-1 -10dB Tilt: about 3 dB less sub-bass, fuller lower mids (+1 dB at 200-500 Hz). The most natural.
- Truthear Hexa: deep sub-bass kept, less glare at 2 and 5 kHz, crisp 7-8 kHz. Clean and tidy.
- Thieaudio Monarch MK3: stock bass, slightly scooped mids, extra 5-8 kHz sparkle. Leans slightly toward Harman treble.
- Harman IE 2019v2: stock sub-bass, leaner lower mids, most 3-7 kHz energy (+1.4 to +3 dB). The brightest.

GENRE RANKING (best -> worst)

Pop                                HBB > IEF > Hexa > Harman > MK3 > JM-1
Hip-hop, Rap, Trap                 HBB > Hexa > IEF > Harman > MK3 > JM-1
EDM, House, Dubstep, DnB           Hexa > HBB > Harman > MK3 > IEF > JM-1
R&B, Soul                          IEF > HBB > JM-1 > Hexa > Harman > MK3
Rock, Indie, Alternative           HBB > Hexa > MK3 > IEF > Harman > JM-1
Metal                              Hexa > HBB > MK3 > IEF > JM-1 > Harman
Jazz                               JM-1 > IEF > Hexa > MK3 > Harman > HBB
Classical, Orchestral, Film scores JM-1 > IEF > Hexa > MK3 > Harman > HBB
Acoustic, Folk, Singer-songwriter  JM-1 > IEF > Hexa > Harman > MK3 > HBB
Vocal, Ballads, OST                IEF > JM-1 > Harman > Hexa > HBB > MK3
K-pop, J-pop, Anime                IEF > HBB > Hexa > JM-1 > MK3 > Harman
Country, Blues, Americana          IEF > HBB > JM-1 > Hexa > Harman > MK3
Reggae, Dub, Reggaeton, Latin      HBB > Hexa > IEF > Harman > MK3 > JM-1
Lo-fi, Chill, Ambient              IEF > HBB > JM-1 > Hexa > MK3 > Harman
Mixed playlist (shuffle)           HBB > IEF

TIPS
- One preset for everything: HBB Bad Guy 2022 (or IEF Preference 2025 if
  you mostly play vocal or acoustic music).
- Listening loud? Move one step toward HBB or IEF.
- A harsh-sounding album? Try IEF whatever the genre.
- Wide-bore stock tips sound about 1-2 dB darker in the treble than narrow.
- Rankings are reasoned from what each EQ changes, not a listening test.
  Trust your ears.

All EQs: AutoEq 4.1.2 on the median of 27 squig.link IEC 711 measurements;
treble changes capped at +3/-4 dB from 5 kHz, no boosts at or above 10 kHz.
Full write-up: README.md in the repo.
